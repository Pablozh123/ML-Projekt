import pandas as pd
import numpy as np
from bokeh.plotting import figure, show
from bokeh.layouts import gridplot
from bokeh.models import HoverTool, LinearAxis, Range1d
from math import pi


# Daten laden
df = pd.read_csv('combined.csv', parse_dates=['Date'])

# Konvertiere alle Spalten in numerische Werte
for col in df.columns:
    if col != 'Date':
        df[col] = pd.to_numeric(df[col], errors='coerce')

# Entferne fehlende Werte
df.dropna(how='any', inplace=True)

print(df.describe())

# Berechne die Korrelationsmatrix
correlation_matrix = df.corr()

# Korrelationsmatrix als Heatmap
corr_fig = figure(title='Correlation Matrix', x_range=list(df.columns[1:]), y_range=list(df.columns[1:]))
corr_fig.image(image=[correlation_matrix.values], x=0, y=0, dw=len(df.columns[1:]), dh=len(df.columns[1:]), palette='Spectral11')
corr_fig.xaxis.major_label_orientation = pi/4
corr_fig.yaxis.major_label_orientation = pi/4

# Plots für jede Variable mit separaten Achsen
plots_with_secondary_axis = []

for col in df.columns[1:-1]:  # Alle Variablen außer 'Date' und 'Adj Close'
    p = figure(width=600, height=200, x_axis_type='datetime',
               title=f'{col} and Adj Close (Separate y-axis)')
    
    # Primäre y-Achse: Skaliert an die aktuelle Variable
    min_primary = df[col].min()
    max_primary = df[col].max()
    p.y_range = Range1d(start=min_primary * 0.9, end=max_primary * 1.1)  # 10% Puffer

    p.line(df['Date'], df[col], color='blue', legend_label=col)
    
    # Sekundäre y-Achse: Skaliert an Adj Close
    min_secondary = df['Adj Close'].min()
    max_secondary = df['Adj Close'].max()
    p.extra_y_ranges = {'Adj Close': Range1d(start=min_secondary * 0.9, end=max_secondary * 1.1)}  # 10% Puffer
    p.add_layout(LinearAxis(y_range_name='Adj Close', axis_label='Adj Close'), 'right')
    p.line(df['Date'], df['Adj Close'], color='green', legend_label='Adj Close', y_range_name='Adj Close')
    
    # HoverTool hinzufügen
    p.add_tools(HoverTool(
        tooltips=[
            ('Date', '@x{%F}'),
            (col, '@y'),
            ('Adj Close', '@Adj Close{0.00}')
        ],
        formatters={
            '@x': 'datetime',
            '@y': 'printf',
            '@Adj Close': 'printf',
        },
        mode='vline'
    ))

    # Position der Legende und hinzufügen zur Liste
    p.legend.location = 'top_left'
    plots_with_secondary_axis.append(p)

# Gridplot erstellen und anzeigen
show(gridplot([[corr_fig], *[[plot] for plot in plots_with_secondary_axis]], sizing_mode='stretch_width'))


