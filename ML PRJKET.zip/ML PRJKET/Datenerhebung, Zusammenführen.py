import pandas_datareader as pdr
import pandas as pd
import datetime
import yfinance as yf

start_date = datetime.datetime(1989, 5, 1)
end_date = datetime.datetime(2024, 10, 5)

indicators = {
    "Unemployment Rate": "UNRATE",
    "Feds Funds": "FEDFUNDS",
    "10-3 Yield Curve": "T10Y3M",
    "Industrial Production": "INDPRO",
    "Housing Starts": "HOUST",
    "Building Permits": "PERMIT",
    "Consumer Sentiment": "UMCSENT",
    "Inflation": "CORESTICKM159SFRBATL",
    "10-2 Year Treasury Spread": "T10Y2Y",
    "Recession": "USRECD",
    "Feds Fund Rate": "DFF"
}

dataframes = {}


for name, code in indicators.items():
    dataframes[name] = pdr.get_data_fred(code, start_date, end_date)

df = pd.concat(dataframes, axis=1)

df.to_csv('Fred.csv')

for name, code in indicators.items():
    df = pdr.get_data_fred(code, start_date, end_date)
    dataframes[name] = df

df = pd.concat(dataframes.values(), axis=1, keys=dataframes.keys())
df.columns = [' '.join(col).strip() for col in df.columns.values]
df.reset_index(inplace=True)

df['DATE'] = pd.to_datetime(df['DATE'])
df.rename(columns={'DATE': 'Date'}, inplace=True)
df.to_csv('Fred.csv', index=False)

df1 = yf.download('^GSPC', start='1989-05-01', end='2024-10-05')
df1 = df1.drop(['Open', 'High', 'Low', 'Close', 'Volume'], axis=1)

df1.reset_index(inplace=True)
df1['Date'] = pd.to_datetime(df1['Date'])
df1.to_csv('SP500.csv')

df1.reset_index(inplace=True)

df1['Date'] = pd.to_datetime(df1['Date'])

df1.to_csv('SP500.csv')

# Entferne MultiIndex (falls vorhanden)
if isinstance(df.columns, pd.MultiIndex):
    df.columns = df.columns.get_level_values(0)
if isinstance(df1.columns, pd.MultiIndex):
    df1.columns = df1.columns.get_level_values(0)

# Entferne Zeitzonen aus der 'Date'-Spalte
df['Date'] = pd.to_datetime(df['Date']).dt.tz_localize(None)
df1['Date'] = pd.to_datetime(df1['Date']).dt.tz_localize(None)

# Überprüfe die Namen der Spalten
df.rename(columns={'DATE': 'Date'}, inplace=True)
df1.rename(columns={'DATE': 'Date'}, inplace=True)

# Kombiniere die DataFrames
combined_df = pd.merge(df, df1, on='Date', how='outer')

# Interpolation für die angegebenen Spalten
d = ['10-2 Year Treasury Spread T10Y2Y', '10-3 Yield Curve T10Y3M', 'Adj Close']
for column in d:
    if column in combined_df.columns:  # Überprüfe, ob die Spalte existiert
        combined_df[column].interpolate(method='linear', inplace=True)

# Entferne verbleibende fehlende Werte
combined_df.dropna(inplace=True)

# Speichere den kombinierten DataFrame
combined_df.to_csv('combined.csv', index=False)



